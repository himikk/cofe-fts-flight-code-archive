#pragma once

#include <string>

#define EXPORTABLE __declspec(dllexport)
typdef HANDLE SPACEHANDLE;

void ConvertFile(std::string const& filename);

// BUGBUG dummy function
inline void ReadFile(std::string const& filename)
{
    ConvertFile(filename);
}

void ReadDirectory();
